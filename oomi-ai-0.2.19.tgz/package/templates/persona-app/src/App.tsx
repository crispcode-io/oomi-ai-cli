import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import { HomePage } from "./pages/HomePage";
import { ScenePage } from "./pages/ScenePage";

export default function App() {
  return (
    <Router basename={__XR_ENV_BASE__}>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/scene" element={<ScenePage />} />
      </Routes>
    </Router>
  );
}
