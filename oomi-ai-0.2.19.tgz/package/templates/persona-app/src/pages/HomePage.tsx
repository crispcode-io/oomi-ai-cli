import { initScene } from "@webspatial/react-sdk";
import { Link } from "react-router-dom";
import "../App.css";
import { personaConfig } from "../persona/config";
import { personaNotes } from "../persona/notes";

export function HomePage() {
  const openSpatialScene = () => {
    initScene("personaScene", prevConfig => ({
      ...prevConfig,
      defaultSize: {
        width: 720,
        height: 720,
      },
    }));
    window.open(`${__XR_ENV_BASE__}/scene`, "personaScene");
  };

  return (
    <main className="persona-shell">
      <section className="persona-header">
        <div className="persona-panel persona-hero">
          <p className="persona-eyebrow">WebSpatial Persona</p>
          <h1 className="persona-title">{personaConfig.name}</h1>
          <p className="persona-description">{personaConfig.description}</p>

          <div className="persona-actions">
            <button className="persona-button" onClick={openSpatialScene} enable-xr>
              Open Spatial Scene
            </button>
            <Link className="persona-link" to="/scene" target="_blank" enable-xr>
              Open Scene Route
            </Link>
          </div>
        </div>

        <aside className="persona-panel persona-runtime">
          <p className="persona-eyebrow">Runtime</p>
          <div className="runtime-list">
            <div>Slug: {personaConfig.slug}</div>
            <div>Template: {personaConfig.templateVersion}</div>
            <div>Engine: WebSpatial + React + Vite</div>
            <div>Mode: local/private</div>
          </div>
        </aside>
      </section>

      <section className="persona-grid">
        <article className="persona-panel persona-card">
          <h2>Editable Persona Notes</h2>
          <p>
            This scaffold follows the WebSpatial quick-example structure so the app can render
            well in both the browser and future XR clients. Keep persona-specific logic in
            <code> src/persona/</code>.
          </p>
          <ul>
            {personaNotes.map(note => (
              <li key={note}>{note}</li>
            ))}
          </ul>
        </article>

        <article className="persona-panel persona-card persona-scene-card" enable-xr>
          <h2>Scene Surface</h2>
          <p enable-xr>
            Use this card as the main spatial handoff. It already uses WebSpatial router
            basenames, scene launching, and `enable-xr` affordances taken from the quick example.
          </p>
        </article>
      </section>
    </main>
  );
}
