import "../App.css";
import { personaConfig } from "../persona/config";

export function ScenePage() {
  return (
    <main className="scene-shell">
      <section className="persona-panel scene-panel">
        <p className="persona-eyebrow">Scene</p>
        <h1>{personaConfig.name}</h1>
        <p>{personaConfig.description}</p>
        <p>
          This route is intentionally separate so WebSpatial scene launching has a dedicated
          surface. Extend this page with persona-specific spatial UI.
        </p>
      </section>
    </main>
  );
}
