export const personaNotes = [
  "Keep persona-specific logic inside src/persona/ unless Oomi explicitly instructs otherwise.",
  "Preserve the WebSpatial router basename and scene-launch flow.",
  "Do not remove public/oomi.runtime.json, public/oomi.health.json, or public/manifest.webmanifest.",
];
