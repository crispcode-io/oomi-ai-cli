# __OOMI_PERSONA_NAME__

This project was scaffolded by `oomi personas scaffold`.

## Purpose

This app is intended to run inside the Oomi client as a managed persona surface and uses the WebSpatial quick-example pattern as its base.

## Editable Zones

Only customize files in these zones unless Oomi explicitly changes the scaffold contract:

- `src/persona/`
- `persona/`

## Runtime Contract

- Template version: `__OOMI_TEMPLATE_VERSION__`
- Health document: `/oomi.health.json`
- Runtime metadata document: `/oomi.runtime.json`
- Manifest: `/manifest.webmanifest`
- Default dev port: `4789`

## Local Development

```bash
npm install
npm run dev
```

## Notes

- Preserve the WebSpatial/Vite shell and the files in `public/`.
- Keep the app safe to embed inside Oomi and future XR clients.
- Customize persona behavior in `src/persona/`.
