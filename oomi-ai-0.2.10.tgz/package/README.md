# oomi-ai

CLI to install Oomi agent instructions and skills into OpenClaw, plus sync personas to the Oomi backend registry.

## Install
```
pnpm add -g oomi-ai
```

Fallback:
```
npm install -g oomi-ai
```

## Usage

Install as an OpenClaw channel extension (preferred architecture):
```
openclaw plugins install oomi-ai@latest
```

This package now ships an OpenClaw channel plugin (`openclaw.plugin.json`) with channel id `oomi`.
Channel account config fields (`channels.oomi.accounts.<accountId>`):
- `backendUrl`
- `deviceToken`
- `defaultSessionKey` (optional, default `agent:main:webchat:channel:oomi`)
- `requestTimeoutMs` (optional)

Print plugin install/config guidance from local pair state:
```
oomi openclaw plugin
```

Install agent instructions only:
```
oomi init
```

Install agent instructions + Oomi skill:
```
oomi openclaw install
```

Pair and provision device token from Oomi web backend:
```
oomi openclaw pair --app-url https://your-oomi-app.vercel.app --device-id my-openclaw-mac --no-start
```

`--app-url` must be reachable from the OpenClaw host. If OpenClaw runs on a different machine/network, do not use `localhost` unless tunneled.

This prints:
- `Auth invite URL: https://.../connect/<single-use-token>`
- A copy-ready block for the user:
  - `Oomi Connect Ready`
  - `Auth Link: ...`

If you need a fresh auth link later (without re-pairing), run:
```
oomi openclaw invite --app-url https://your-oomi-app.vercel.app
```

Bridge lifecycle handler (singleton, one bridge per host/device):
```
oomi openclaw bridge ensure --detach   # start if needed; no-op if already running
oomi openclaw bridge ps                # list bridge pids
oomi openclaw bridge stop              # stop all bridge workers
oomi openclaw bridge restart --detach  # clean restart as background worker
```
`oomi openclaw bridge --detach` is equivalent to `oomi openclaw bridge start --detach`.

Agent-intent mapping (recommended):
- If user says `Connect yourself to Oomi. Use app URL https://www.oomi.ai.`
- Run:
  - `curl -fsSL https://www.oomi.ai/install.sh | bash`
  - or `pnpm add -g oomi-ai@latest` (`npm install -g oomi-ai@latest` fallback)
  - `oomi openclaw pair --app-url https://www.oomi.ai --no-start`
  - `openclaw plugins install oomi-ai@latest`
  - `oomi openclaw plugin --show-secrets --backend-url https://api.oomi.ai`
  - Apply `channels.oomi.accounts.default` config and restart OpenClaw.

Important distinction:
- `pairCode` is one-time and used internally by the pair/bootstrap flow.
- Invite auth links are the required user flow.
- Managed chat connect now uses OpenClaw challenge auth (`connect.challenge` nonce + signed device payload) in the local bridge path.

Sync personas from the repo into the backend registry:
```
oomi personas sync --backend-url http://localhost:3001
```

Create a new persona (and sync it):
```
oomi personas create chef --name "Oomi Chef" --summary "Cooking ideas and nutrition guidance"
```

Optional flags:
```
oomi init --workspace /path/to/openclaw/workspace
oomi init --agents-file /path/to/AGENTS.md
oomi openclaw install --skills-dir /path/to/openclaw/skills
oomi openclaw pair --app-url https://your-oomi-app.vercel.app --no-start
oomi openclaw pair --app-url https://your-oomi-app.vercel.app --json
oomi personas sync --root /path/to/oomi
oomi personas create creator --status active --chat-session agent:main:webchat:channel:oomi-creator
```

Defaults:
- Agent instructions are written to `$OPENCLAW_WORKSPACE/AGENTS.md` (if set), otherwise `~/.openclaw/workspace/AGENTS.md`.
- Skills are installed to `~/.openclaw/skills` and `~/clawd/skills` if present.

Restart OpenClaw after running `oomi init` or `oomi openclaw install`.

## Update Notifications
- `oomi` checks npm for a newer `oomi-ai` version on normal commands (cached, best-effort).
- When an update is available it prints:
  - `pnpm add -g oomi-ai@latest`
  - fallback: `npm install -g oomi-ai@latest`
- Optional env controls:
  - `OOMI_SKIP_UPDATE_CHECK=1` disables checks
  - `OOMI_UPDATE_CHECK_INTERVAL_MS=<ms>` changes check interval
  - `OOMI_UPDATE_CHECK_TIMEOUT_MS=<ms>` changes network timeout
  - `OOMI_BRIDGE_GATEWAY_CONNECT_TIMEOUT_MS=<ms>` changes local gateway socket connect timeout
  - `OOMI_BRIDGE_CONNECT_CHALLENGE_TIMEOUT_MS=<ms>` changes wait timeout for gateway `connect.challenge` nonce

## Package Audit + Publish (pnpm)
```
cd <repo-root>/packages/oomi-ai
pnpm check
pnpm publish --dry-run --no-git-checks --access public
pnpm publish --access public
```
