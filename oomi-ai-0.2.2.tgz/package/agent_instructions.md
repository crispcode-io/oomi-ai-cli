# Oomi Avatar Control

Before using avatar commands, call `get_avatar_capabilities` and prefer canonical values.
Inline tags are stripped from user-visible text.

Use inline tags like:
- [anim:Waving], [anim:Walking], [anim:Idle], [anim:Sitting Idle]
- [face:happy], [face:sad], [face:surprised], [face:focused], [face:gentle], [face:thinking]
- [gesture:nod], [gesture:think], [gesture:shrug], [gesture:wave], [gesture:bow]
- [look:camera], [look:left], [look:right], [look:up], [look:down]

Aliases allowed (if needed): wave -> Waving, walk -> Walking, idle -> Idle, sit/sitting -> Sitting Idle

## Oomi Connect Flow

If the user asks to connect OpenClaw to Oomi voice/web:

1. Refresh bootstrap/update first:
   - `curl -fsSL https://www.oomi.ai/install.sh | bash`
2. Ensure `oomi-ai` is installed (`pnpm add -g oomi-ai@latest`).
   - Fallback: `npm install -g oomi-ai@latest`
3. Pair device token without starting legacy bridge:
   - `oomi openclaw pair --app-url https://www.oomi.ai --no-start`
4. Install OpenClaw plugin:
   - `openclaw plugins install oomi-ai@latest`
5. Configure channel account (`channels.oomi.accounts.default`) from:
   - `oomi openclaw plugin --show-secrets --backend-url https://api.oomi.ai`
6. Restart OpenClaw.
7. If user provides an app URL (for example "Connect yourself to Oomi. Use app URL <URL>."):
   - Use that URL directly in the pair command.
   - Example: `oomi openclaw pair --app-url <URL> --no-start`
8. Return this exact result format to the user:
   - `Oomi Connect Ready`
   - `Auth Link: ...`
   - No extra narrative text before or after those lines.

Primary UX requirement:
- Do not ask the user to manually enter a connect code when an auth link is available.
- The user should open the auth link, complete sign-in, and land directly in connected chat.
- Do not return `/?connect=managed://...` links to users; return `/connect/<invite-token>` only.

Do not ask users to paste gateway IP/token/password when managed connect is available.
