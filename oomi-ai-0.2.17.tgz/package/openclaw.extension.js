const CHANNEL_ID = 'oomi';
const DEFAULT_SESSION_KEY = 'agent:main:webchat:channel:oomi';
const DEFAULT_TIMEOUT_MS = 15000;

function toString(value, fallback = '') {
  return typeof value === 'string' && value.trim() ? value.trim() : fallback;
}

function toNumber(value, fallback, { min = 1, max = Number.MAX_SAFE_INTEGER } = {}) {
  if (typeof value !== 'number' || !Number.isFinite(value)) return fallback;
  const normalized = Math.floor(value);
  if (normalized < min) return fallback;
  if (normalized > max) return max;
  return normalized;
}

function parseAccounts(rawAccounts) {
  if (!rawAccounts || typeof rawAccounts !== 'object') return {};
  const accounts = {};

  for (const [accountId, raw] of Object.entries(rawAccounts)) {
    if (!raw || typeof raw !== 'object') continue;
    accounts[accountId] = {
      enabled: raw.enabled !== false,
      backendUrl: toString(raw.backendUrl),
      deviceToken: toString(raw.deviceToken),
      defaultSessionKey: toString(raw.defaultSessionKey, DEFAULT_SESSION_KEY),
      requestTimeoutMs: toNumber(raw.requestTimeoutMs, DEFAULT_TIMEOUT_MS, { min: 2000, max: 120000 }),
    };
  }

  return accounts;
}

function extractChannelConfig(cfg = {}) {
  if (!cfg || typeof cfg !== 'object') return {};
  if (cfg.channels && typeof cfg.channels === 'object' && cfg.channels[CHANNEL_ID] && typeof cfg.channels[CHANNEL_ID] === 'object') {
    return cfg.channels[CHANNEL_ID];
  }
  if (cfg[CHANNEL_ID] && typeof cfg[CHANNEL_ID] === 'object') {
    return cfg[CHANNEL_ID];
  }
  if (cfg.accounts && typeof cfg.accounts === 'object') {
    return cfg;
  }
  return {};
}

function normalizeConfig(cfg = {}) {
  const channelConfig = extractChannelConfig(cfg);
  const configuredAccounts = parseAccounts(channelConfig.accounts);
  const accountIds = Object.keys(configuredAccounts);
  const defaultAccountId = toString(channelConfig.defaultAccountId, accountIds[0] || 'default');

  if (!configuredAccounts[defaultAccountId]) {
    configuredAccounts[defaultAccountId] = {
      enabled: true,
      backendUrl: '',
      deviceToken: '',
      defaultSessionKey: DEFAULT_SESSION_KEY,
      requestTimeoutMs: DEFAULT_TIMEOUT_MS,
    };
  }

  return {
    defaultAccountId,
    accounts: configuredAccounts,
  };
}

function resolveAccount(cfg, accountId) {
  const normalized = normalizeConfig(cfg);
  const resolvedId = toString(accountId, normalized.defaultAccountId);
  const account = normalized.accounts[resolvedId];
  if (!account) {
    return {
      accountId: resolvedId,
      account: null,
    };
  }

  return {
    accountId: resolvedId,
    account,
  };
}

function extractText(payload) {
  if (!payload) return '';
  if (typeof payload === 'string') return payload.trim();

  const direct = [payload.text, payload.message, payload.content, payload.body];
  for (const value of direct) {
    if (typeof value === 'string' && value.trim()) return value.trim();
  }

  if (Array.isArray(payload.content)) {
    return payload.content
      .filter((part) => part && typeof part === 'object' && part.type === 'text' && typeof part.text === 'string')
      .map((part) => part.text.trim())
      .filter(Boolean)
      .join('\n');
  }

  return '';
}

function extractConversationKey(payload) {
  const candidates = [
    payload?.conversationKey,
    payload?.threadId,
    payload?.target?.conversationKey,
    payload?.target?.threadId,
    payload?.target?.id,
    payload?.metadata?.conversationKey,
    payload?.metadata?.threadId,
  ];

  for (const candidate of candidates) {
    const value = toString(candidate);
    if (value) return value;
  }

  return '';
}

function extractUserId(payload) {
  const candidates = [
    payload?.userId,
    payload?.target?.userId,
    payload?.metadata?.userId,
  ];

  for (const candidate of candidates) {
    const value = toString(candidate);
    if (value) return value;
  }

  return '';
}

function nextMessageId() {
  return `oomi_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 10)}`;
}

function extractMessageId(payload) {
  const candidates = [
    payload?.messageId,
    payload?.id,
    payload?.requestId,
    payload?.idempotencyKey,
    payload?.metadata?.messageId,
    payload?.metadata?.idempotencyKey,
  ];

  for (const candidate of candidates) {
    const value = toString(candidate);
    if (value) return value;
  }

  return nextMessageId();
}

function extractCorrelationId(payload) {
  const candidates = [
    payload?.correlationId,
    payload?.metadata?.correlationId,
    payload?.requestId,
    payload?.messageId,
    payload?.id,
  ];

  for (const candidate of candidates) {
    const value = toString(candidate);
    if (value) return value;
  }

  return '';
}

const BOUNDED_LANGUAGE_TYPES = new Set([
  'Auto',
  'Chinese',
  'English',
  'German',
  'Italian',
  'Portuguese',
  'Spanish',
  'Japanese',
  'Korean',
  'French',
  'Russian',
]);

const BOUNDED_PACE_VALUES = new Set(['very_slow', 'slow', 'medium', 'medium_fast', 'fast']);
const BOUNDED_PITCH_VALUES = new Set(['low', 'slightly_low', 'neutral', 'slightly_high', 'high']);
const BOUNDED_ENERGY_VALUES = new Set(['soft', 'calm', 'warm', 'bright', 'intense']);
const BOUNDED_VOLUME_VALUES = new Set(['soft', 'normal', 'projected']);

function inferSpokenLanguage(text) {
  const normalized = toString(text);
  if (!normalized) return 'English';
  return 'English';
}

function normalizeSpokenSegment(segment) {
  if (!segment || typeof segment !== 'object' || Array.isArray(segment)) return null;

  const text = toString(segment.text);
  if (!text) return null;

  const normalized = { text };
  const pace = toString(segment.pace);
  const pitch = toString(segment.pitch);
  const energy = toString(segment.energy);
  const volume = toString(segment.volume);
  const pauseAfterMs = toNumber(segment.pause_after_ms, 0, { min: 0, max: 1200 });

  if (BOUNDED_PACE_VALUES.has(pace)) normalized.pace = pace;
  if (BOUNDED_PITCH_VALUES.has(pitch)) normalized.pitch = pitch;
  if (BOUNDED_ENERGY_VALUES.has(energy)) normalized.energy = energy;
  if (BOUNDED_VOLUME_VALUES.has(volume)) normalized.volume = volume;
  normalized.pause_after_ms = pauseAfterMs;

  return normalized;
}

function splitSpeechSegments(text) {
  const normalized = normalizeSpeechText(text);
  if (!normalized) return [];

  const baseSegments = normalized
    .split(/(?<=[.!?])\s+/)
    .map((segment) => segment.trim())
    .filter(Boolean);

  const segments = [];
  for (const segment of baseSegments) {
    if (segment.length <= 96) {
      segments.push(segment);
      continue;
    }

    const clauseParts = segment
      .split(/,\s+/)
      .map((part) => part.trim())
      .filter(Boolean);

    if (clauseParts.length > 1) {
      for (let index = 0; index < clauseParts.length; index += 1) {
        const part = clauseParts[index];
        const needsComma = index < clauseParts.length - 1 && !/[.!?]$/.test(part);
        segments.push(needsComma ? `${part},` : part);
      }
      continue;
    }

    segments.push(segment);
  }

  if (segments.length <= 5) return segments;

  return [...segments.slice(0, 4), segments.slice(4).join(' ').trim()];
}

function inferSegmentStyle(segmentText, index, totalSegments) {
  const normalized = segmentText.toLowerCase();
  const exclamatory = /!/.test(segmentText) || /\b(hell yeah|awesome|amazing|stoked|love|perfect|great)\b/.test(normalized);
  const curious = /\?/.test(segmentText);
  const reflective =
    /\b(i think|i'm|i am|i've|i have|lately|right now|before this|each time|understand|it feels like)\b/.test(normalized) ||
    segmentText.length > 60;

  if (curious) {
    return {
      pace: 'medium',
      pitch: 'slightly_high',
      energy: 'warm',
      volume: 'normal',
      pause_after_ms: 0,
    };
  }

  if (exclamatory) {
    return {
      pace: 'medium_fast',
      pitch: 'slightly_high',
      energy: 'bright',
      volume: 'normal',
      pause_after_ms: index < totalSegments - 1 ? 220 : 0,
    };
  }

  if (reflective) {
    return {
      pace: 'medium',
      pitch: 'neutral',
      energy: 'warm',
      volume: 'normal',
      pause_after_ms: index < totalSegments - 1 ? 260 : 0,
    };
  }

  return {
    pace: 'medium',
    pitch: 'neutral',
    energy: 'warm',
    volume: 'normal',
    pause_after_ms: index < totalSegments - 1 ? 180 : 0,
  };
}

function synthesizeSpokenSegments(text) {
  const language = inferSpokenLanguage(text);
  const rawSegments = splitSpeechSegments(text);
  if (rawSegments.length === 0) return null;

  const segments = rawSegments.map((segmentText, index) => ({
    text: segmentText,
    ...inferSegmentStyle(segmentText, index, rawSegments.length),
  }));

  return {
    language,
    segments,
  };
}

function normalizeSpokenMetadata(spoken) {
  if (!spoken || typeof spoken !== 'object' || Array.isArray(spoken)) return null;

  const text = toString(spoken.text);
  if (!text) return null;

  const normalized = { text };
  const language = toString(spoken.language);
  if (BOUNDED_LANGUAGE_TYPES.has(language)) {
    normalized.language = language;
  }

  const explicitSegments =
    Array.isArray(spoken.segments)
      ? spoken.segments.map((segment) => normalizeSpokenSegment(segment)).filter(Boolean)
      : [];
  if (explicitSegments.length > 0) {
    normalized.segments = explicitSegments;
  }

  const instructions = toString(spoken.instructions);
  if (instructions) normalized.instructions = instructions;
  if (spoken.style && typeof spoken.style === 'object' && !Array.isArray(spoken.style)) {
    normalized.style = spoken.style;
  }

  const fallbackSegments = synthesizeSpokenSegments(text);
  if (!normalized.language && fallbackSegments?.language) {
    normalized.language = fallbackSegments.language;
  }
  if (!normalized.segments && fallbackSegments?.segments?.length) {
    normalized.segments = fallbackSegments.segments;
  }

  return normalized;
}

function stripEmoji(text) {
  return text.replace(/[\uFE0E\uFE0F]/g, '').replace(/\p{Extended_Pictographic}|\p{Emoji_Presentation}/gu, '');
}

function normalizeSpeechText(text) {
  return stripEmoji(text)
    .replace(/\*\*(.*?)\*\*/g, '$1')
    .replace(/__(.*?)__/g, '$1')
    .replace(/`([^`]+)`/g, '$1')
    .replace(/[–—]/g, ', ')
    .replace(/…/g, '...')
    .replace(/\s+/g, ' ')
    .replace(/\s+([,.;!?])/g, '$1')
    .replace(/([,.;!?])(?=[^\s])/g, '$1 ')
    .replace(/,\s*,+/g, ', ')
    .replace(/\s+/g, ' ')
    .trim();
}

function inferSpokenMetadataFromContent(content) {
  const text = normalizeSpeechText(toString(content));
  if (!text) return null;
  const synthesized = synthesizeSpokenSegments(text);

  const normalized = text.toLowerCase();
  const upbeat =
    /!/.test(text) ||
    /\b(hell yeah|awesome|amazing|great|stoked|love|glad|perfect|nice|cool)\b/.test(normalized);
  const gentle =
    /\b(sorry|gentle|softly|careful|reassuring|calm|okay|it'?s okay|i know)\b/.test(normalized);
  const curious = /\?/.test(text);

  if (upbeat) {
    return {
      text,
      language: synthesized?.language || 'English',
      segments: synthesized?.segments,
      instructions: 'Speak with warm, upbeat conversational energy and natural pacing.',
      style: { emotion: 'upbeat', energy: 'medium' },
    };
  }

  if (gentle) {
    return {
      text,
      language: synthesized?.language || 'English',
      segments: synthesized?.segments,
      instructions: 'Speak gently and reassuringly, with a calm pace and soft emphasis.',
      style: { emotion: 'gentle', energy: 'low' },
    };
  }

  if (curious) {
    return {
      text,
      language: synthesized?.language || 'English',
      segments: synthesized?.segments,
      instructions: 'Speak naturally with curious, engaged intonation and a conversational pace.',
      style: { emotion: 'curious', energy: 'medium' },
    };
  }

  return {
    text,
    language: synthesized?.language || 'English',
    segments: synthesized?.segments,
    instructions: 'Speak naturally with light warmth and conversational pacing.',
    style: { emotion: 'neutral', energy: 'medium' },
  };
}

function normalizeOutgoingMetadata(payloadMetadata, { accountId, correlationId, content }) {
  const metadata =
    payloadMetadata && typeof payloadMetadata === 'object' && !Array.isArray(payloadMetadata)
      ? { ...payloadMetadata }
      : {};

  const explicitSpokenPresent = Object.prototype.hasOwnProperty.call(metadata, 'spoken');
  const spoken =
    normalizeSpokenMetadata(metadata.spoken) ||
    (!explicitSpokenPresent ? inferSpokenMetadataFromContent(content) : null);
  if (spoken) {
    metadata.spoken = spoken;
  } else {
    delete metadata.spoken;
  }

  metadata.accountId = accountId;
  if (correlationId) {
    metadata.correlationId = correlationId;
  } else {
    delete metadata.correlationId;
  }

  return metadata;
}

async function postJson({ url, token, body, timeoutMs }) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify(body),
      signal: controller.signal,
    });

    const payload = await response.json().catch(() => ({}));
    return {
      ok: response.ok,
      status: response.status,
      payload,
    };
  } finally {
    clearTimeout(timeout);
  }
}

const oomiChannelPlugin = {
  id: CHANNEL_ID,
  meta: {
    label: 'Oomi',
    selectionLabel: 'Oomi (Managed)',
    docsPath: '/channels/oomi',
    docsLabel: 'oomi',
    blurb: 'Managed channel transport for Oomi chat.',
    aliases: ['oomi-ai'],
    description: 'Managed Oomi channel plugin.',
  },
  capabilities: {
    chatTypes: ['direct'],
    media: {
      images: false,
      audio: false,
      files: false,
    },
    threads: true,
  },

  config: {
    listAccountIds(cfg) {
      const normalized = normalizeConfig(cfg);
      return Object.entries(normalized.accounts)
        .filter(([, account]) => account.enabled !== false)
        .map(([accountId]) => accountId);
    },

    resolveAccount(cfg, accountId) {
      const { accountId: resolvedAccountId, account } = resolveAccount(cfg, accountId);
      if (!account) return null;
      return {
        id: resolvedAccountId,
        ...account,
      };
    },
  },

  outbound: {
    deliveryMode: 'direct',

    async sendText(payload = {}) {
      const { cfg, accountId } = payload;
      const { accountId: resolvedAccountId, account } = resolveAccount(cfg, accountId);

      if (!account || account.enabled === false) {
        return {
          ok: false,
          error: `oomi account is disabled or missing (${resolvedAccountId})`,
        };
      }
      if (!account.backendUrl || !account.deviceToken) {
        return {
          ok: false,
          error: `oomi account is missing backendUrl/deviceToken (${resolvedAccountId})`,
        };
      }

      const content = extractText(payload);
      if (!content) {
        return {
          ok: false,
          error: 'oomi outbound message content is empty',
        };
      }

      const conversationKey = extractConversationKey(payload);
      const userId = extractUserId(payload);
      const sessionKey = toString(payload?.sessionKey || payload?.metadata?.sessionKey, account.defaultSessionKey);
      const messageId = extractMessageId(payload);
      const correlationId = extractCorrelationId(payload);

      const response = await postJson({
        url: `${account.backendUrl}/v1/channel/plugin/messages`,
        token: account.deviceToken,
        timeoutMs: account.requestTimeoutMs,
        body: {
          messageId,
          correlationId,
          conversationKey,
          userId,
          sessionKey,
          content,
          source: 'openclaw.channel',
          metadata: normalizeOutgoingMetadata(payload?.metadata, {
            accountId: resolvedAccountId,
            correlationId,
            content,
          }),
        },
      });

      if (!response.ok) {
        const reason = toString(response.payload?.error, `status ${response.status}`);
        const code = toString(response.payload?.errorCode);
        return {
          ok: false,
          error: `oomi plugin message publish failed: ${reason}${code ? ` (code=${code})` : ''}`,
          code,
        };
      }

      return {
        ok: true,
        providerMessageId: toString(response.payload?.message?.messageId),
      };
    },
  },
};

export default function register(api) {
  api.registerChannel({ plugin: oomiChannelPlugin });
}
