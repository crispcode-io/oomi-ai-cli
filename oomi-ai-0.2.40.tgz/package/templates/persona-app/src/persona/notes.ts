export const personaNotes = [
  "Keep persona-specific logic inside src/persona/ unless Oomi explicitly instructs otherwise.",
  "Preserve the WebSpatial router basename, the scene self-init helper, and the scene-launch flow.",
  "Keep using the vendored AndroidXR-enabled WebSpatial fork instead of switching back to the stock npm packages.",
  "Author key surfaces with explicit enable-xr, --xr-back, and --xr-background-material values so the page reads as spatial instead of flat.",
  "Do not remove public/oomi.runtime.json, public/oomi.health.json, or public/manifest.webmanifest.",
];
