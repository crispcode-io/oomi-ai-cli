import { useEffect } from "react";
import { Link } from "react-router-dom";
import "../App.css";
import { personaConfig } from "../persona/config";
import { personaNotes } from "../persona/notes";
import {
  WEBSPATIAL_FORK_COMMIT,
  configurePersonaScene,
  detectSpatialEnvironment,
  openPersonaScene,
  xrStyle,
} from "../spatial";

const previewCards = [
  {
    tone: "ocean",
    title: "Focused surface",
    body: "Use the persona site as a real operator board, planner, studio, or dashboard instead of another chat clone.",
    depth: 34,
    material: "translucent",
  },
  {
    tone: "coral",
    title: "Depth-authored cards",
    body: "Key controls should declare their own depth and material so AndroidXR reads them as layered surfaces.",
    depth: 84,
    material: "thin",
  },
  {
    tone: "violet",
    title: "Persistent handoff",
    body: "Let Oomi keep the live conversation thread while the persona page stays focused on structured work.",
    depth: 140,
    material: "thick",
  },
];

type HomePageProps = {
  sceneMode?: boolean;
};

export function HomePage({ sceneMode = false }: HomePageProps) {
  const environment = detectSpatialEnvironment();

  useEffect(() => {
    configurePersonaScene();
  }, []);

  return (
    <main className="persona-shell" enable-xr-monitor={sceneMode || undefined}>
      <section className="persona-header">
        <div className="persona-panel persona-hero" enable-xr style={xrStyle(22, "translucent")}>
          <div>
            <p className="persona-eyebrow">{sceneMode ? "Spatial Persona Surface" : "WebSpatial Persona"}</p>
            <h1 className="persona-title">{personaConfig.name}</h1>
            <p className="persona-description">{personaConfig.description}</p>
          </div>

          <div className="persona-actions">
            {!sceneMode ? (
              <>
                <button className="persona-button" onClick={openPersonaScene} enable-xr style={xrStyle(52, "regular")}>
                  Launch Spatial Surface
                </button>
                <Link className="persona-link" to="/scene" target="_blank" enable-xr style={xrStyle(92, "thin")}>
                  Open Spatial Preview
                </Link>
              </>
            ) : (
              <Link className="persona-button" to="/" enable-xr style={xrStyle(52, "regular")}>
                Return To Browser View
              </Link>
            )}
          </div>

          <div className="persona-preview-strip">
            {previewCards.map(card => (
              <article
                key={card.title}
                className="persona-preview-card"
                data-tone={card.tone}
                enable-xr
                style={xrStyle(card.depth, card.material)}
              >
                <h3>{card.title}</h3>
                <p>{card.body}</p>
              </article>
            ))}
          </div>
        </div>

        <aside className="persona-panel persona-runtime" enable-xr style={xrStyle(72, "thin")}>
          <p className="persona-eyebrow">Runtime</p>
          <div className="runtime-list">
            <div className="runtime-row">
              <span className="runtime-label">Slug</span>
              <span className="runtime-value">{personaConfig.slug}</span>
            </div>
            <div className="runtime-row">
              <span className="runtime-label">SDK</span>
              <span className="runtime-value">@webspatial/react-sdk {environment.sdkVersion}</span>
            </div>
            <div className="runtime-row">
              <span className="runtime-label">Bridge</span>
              <span className="runtime-value">{environment.hasBridge ? "available" : "waiting"}</span>
            </div>
            <div className="runtime-row">
              <span className="runtime-label">Native</span>
              <span className="runtime-value">{environment.nativeVersion ?? "browser fallback"}</span>
            </div>
            <div className="runtime-row">
              <span className="runtime-label">Fork</span>
              <span className="runtime-value">{WEBSPATIAL_FORK_COMMIT.slice(0, 7)}</span>
            </div>
          </div>
        </aside>
      </section>

      <section className="persona-grid">
        <article className="persona-panel persona-card" enable-xr style={xrStyle(34, "translucent")}>
          <h2>What Good XR Feels Like</h2>
          <p>
            Treat the generated persona site like a spatial work surface. The XR route should keep
            the actual persona shell intact, then layer depth, materials, and anchored surfaces on
            top instead of swapping in a disconnected demo board.
          </p>
          <p>
            {sceneMode
              ? "This route is the AndroidXR work surface. It should feel like the same persona site, just spatialized."
              : "This home route exists for browser parity and one-click launch into the spatial work surface."}
          </p>
        </article>

        <article className="persona-panel persona-card" enable-xr style={xrStyle(74, "thin")}>
          <h2>Editing Notes</h2>
          <ul className="persona-note-list">
            {personaNotes.map(note => (
              <li key={note}>{note}</li>
            ))}
          </ul>
        </article>

        <article className="persona-panel persona-card persona-scene-card" enable-xr style={xrStyle(118, "regular")}>
          <h2>Scene Contract</h2>
          <p>
            The page should import WebSpatial helpers, self-configure the scene, and keep using
            explicit <code>enable-xr</code>, <code>--xr-back</code>, and
            <code> --xr-background-material</code> values on important surfaces.
          </p>
        </article>
      </section>
    </main>
  );
}
