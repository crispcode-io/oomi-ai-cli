import { HomePage } from "./HomePage";

export function ScenePage() {
  return <HomePage sceneMode />;
}
