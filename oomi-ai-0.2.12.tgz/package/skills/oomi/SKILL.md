---
name: oomi
description: Interact with the Oomi 3D Avatar application to retrieve health data, set goals, and control the avatar persona.
---

# Oomi Skill

This skill allows you to interact with the running Oomi application (localhost). You can fetch user activity data, set new goals, and sync context.

## Prerequisites

- The Oomi Next.js app must be running locally (`npm run dev`) at `http://localhost:3000`.

## Configuration

Before using the skill, run the setup script to configure the API URL:
```python
python3 skills/oomi/setup.py
```
Default URL is `http://localhost:3000/api/skill`.

## Tools

### `get_data`
Fetches the user's latest health and activity data from the Oomi app.

**Usage:**
```python
python3 skills/oomi/scripts/get_data.py
```

**Returns:**
JSON string containing:
- `steps`: Daily step count
- `sleep`: Sleep duration in hours
- `energy`: Calculated energy level (0-100)
- `mood`: Current user mood (if tracked)

### `set_goal`
Sets a new activity or behavior goal for the user in the Oomi app.

**Usage:**
```python
python3 skills/oomi/scripts/send_goal.py --type "steps" --value 10000 --message "Let's hit 10k today!"
```

**Arguments:**
- `--type`: Type of goal (e.g., "steps", "sleep", "focus")
- `--value`: Target value (number)
- `--message`: Motivational message to display to the user

### `sync`
Performs a full context sync, updating Oomi with the Agent's current understanding of the user's state.

**Usage:**
```python
python3 skills/oomi/scripts/sync.py
```

### `get_avatar_capabilities`
Returns the current avatar command schema (supported animations, expressions, gestures, and aliases).

**Usage:**
```python
python3 skills/oomi/scripts/get_avatar_capabilities.py
```

**Returns:**
JSON containing:
- `commands.anim.values` (supported animation names)
- `commands.anim.aliases` (accepted shorthand -> animation name)
- `commands.face.values` (supported expressions)
- `commands.gesture.values` (supported gestures)
- `commands.look.values` (supported look targets)

### `install_agent_instructions`
Installs Oomi avatar command instructions into an OpenClaw `AGENTS.md` file.

**Usage:**
```python
python3 skills/oomi/scripts/install_agent_instructions.py
```

**Options:**
- `--agents-file` Path to the `AGENTS.md` file (defaults to `OPENCLAW_WORKSPACE/AGENTS.md` or repo `AGENTS.md`).
- `--instructions-file` Override the instructions markdown file.

## Persona Control (Inline)

In addition to these scripts, you can control the avatar's visualization directly in your text responses using the following tags. These tags are invisible to the user.

- **Animations (canonical)**: `[anim:Waving]`, `[anim:Walking]`, `[anim:Idle]`, `[anim:Sitting Idle]`
  - **Aliases**: `wave -> Waving`, `walk -> Walking`, `idle -> Idle`, `sit/sitting -> Sitting Idle`
- **Expressions**: `[face:happy]`, `[face:sad]`, `[face:surprised]`, `[face:focused]`, `[face:gentle]`, `[face:thinking]`, `[face:curious]`, `[face:confused]`
- **Gestures**: `[gesture:nod]`, `[gesture:think]`, `[gesture:shrug]`, `[gesture:wave]`, `[gesture:bow]`
- **Gaze**: `[look:camera]`, `[look:left]`, `[look:right]`, `[look:up]`, `[look:down]`

**Example:**
"I see you didn't sleep well last night. [face:worried] [gesture:think] Maybe we should take it easy today?"

**Recommended instruction for agents:**
Before emitting avatar commands, call `get_avatar_capabilities` and prefer canonical values. Use aliases only if explicitly needed.
